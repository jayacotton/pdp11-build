
**** PDP11GUI.EXE README ****

- PDP11GUI is better than its user interface,
  so be sure to read the documentation at
  http://www.retrocmp.com/tools/pdp11gui

- PDP11GUI is under development.
  Documented features are at least of "beta" status.
  If you detect some undocumented features, you better don't use them!

- Revision history is found in "history.txt"

- After first start of PDP11GUI, you should follow the tutorial:
  http://www.retrocmp.com/tools/pdp11gui/tutorial

- You will find errors, mail them directly to
  j_hoppe@t-online.de


Enjoy!

Joerg

